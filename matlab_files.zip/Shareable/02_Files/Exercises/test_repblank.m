function tests = test_repblank

tests = functiontests( localfunctions() );

end

function test_OneBlank(testCase) %#ok<*DEFNU>

end

function test_ManyBlank(testCase)

end

function test_FirstBlank(testCase)

end

function test_LastBlank(testCase)

end

