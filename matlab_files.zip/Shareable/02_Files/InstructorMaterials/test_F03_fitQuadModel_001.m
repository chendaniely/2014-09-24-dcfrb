function tests = test_F03_fitQuadModel_001
    % TEST_FITQUADMODEL Main test function for the algorithm implemented in
    % fitQuadModel. To run the tests defined here, use RUNTESTS.
    % See also F02_fitQuadModel, runtests.
    
    % Test array constructed from local functions in this file.
    tests = functiontests( localfunctions() );
    
end % test_fitQuadModel