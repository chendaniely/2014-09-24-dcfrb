function [modelCoeffs, fh] = F02_fitQuadModel_002(X, y, showplot)
    % FITQUADMODEL Fits a quadratic model to the response data y using the
    % columns of X as regressors. X has one or two columns; y is a vector with
    % the same number of rows as X.    
    
    
end % main function fitQuadModel

function [XClean, yClean] = removeNaNs(X, y)   
        
end % removeNaNs

function modelCoeffs = fitModel(XClean, yClean)    
        
end % fitModel

function fh = visualiseResults(X, y, XClean, modelCoeffs)
    
end % visualiseResults